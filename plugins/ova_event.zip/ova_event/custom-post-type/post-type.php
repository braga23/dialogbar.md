<?php if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Slideshow //////////////////////////////////////////
add_action( 'init', 'slideshow_init',0 );
function slideshow_init() {
    
    $labels = array(
        'name'               => __( 'Slideshows', 'post type general name', 'event' ),
        'singular_name'      => __( 'Slide', 'post type singular name', 'event' ),
        'menu_name'          => __( 'Slideshows', 'admin menu', 'event' ),
        'name_admin_bar'     => __( 'Slide', 'add new on admin bar', 'event' ),
        'add_new'            => __( 'Add New slide', 'Slide', 'event' ),
        'add_new_item'       => __( 'Add New Slide', 'event' ),
        'new_item'           => __( 'New Slide', 'event' ),
        'edit_item'          => __( 'Edit Slide', 'event' ),
        'view_item'          => __( 'View Slide', 'event' ),
        'all_items'          => __( 'All Slides', 'event' ),
        'search_items'       => __( 'Search Slides', 'event' ),
        'parent_item_colon'  => __( 'Parent Slides:', 'event' ),
        'not_found'          => __( 'No Slides found.', 'event' ),
        'not_found_in_trash' => __( 'No Slides found in Trash.', 'event' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'menu_icon'          => 'dashicons-format-gallery',
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'slideshow' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail','comments'),
        'taxonomies'          => array('slidegroup'),
    );

    register_post_type( 'slideshow', $args );
}


add_action( 'init', 'create_slidegroup_taxonomies', 0 );
// create slidegroup taxonomy
function create_slidegroup_taxonomies() {
    // Add new taxonomy, make it hierarchical (like categories)
    $labels = array(
        'name'              => __( 'Group', 'taxonomy general name' , 'event'),
        'singular_name'     => __( 'Group', 'taxonomy singular name' , 'event'),
        'search_items'      => __( 'Search Group', 'event'),
        'all_items'         => __( 'All Group', 'event' ),
        'parent_item'       => __( 'Parent Group', 'event' ),
        'parent_item_colon' => __( 'Parent Group:' , 'event'),
        'edit_item'         => __( 'Edit Group' , 'event'),
        'update_item'       => __( 'Update Group' , 'event'),
        'add_new_item'      => __( 'Add New Group' , 'event'),
        'new_item_name'     => __( 'New Group Name' , 'event'),
        'menu_name'         => __( 'Group' , 'event'),
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'slideshow' )
    );

    register_taxonomy( 'slidegroup', array('slideshow'), $args );
}







// Schedule /////////////////////////////////////////////////////////
add_action( 'init', 'schedule_post_type', 0 );
function schedule_post_type() {

    $labels = array(
        'name'                => __( 'Schedule', 'Post Type General Name', 'event' ),
        'singular_name'       => __( 'Schedule', 'Post Type Singular Name', 'event' ),
        'menu_name'           => __( 'Schedule', 'event' ),
        'parent_item_colon'   => __( 'Parent Schedule:', 'event' ),
        'all_items'           => __( 'All Schedules', 'event' ),
        'view_item'           => __( 'View Schedule', 'event' ),
        'add_new_item'        => __( 'Add New Schedule', 'event' ),
        'add_new'             => __( 'Add New Schedule', 'event' ),
        'edit_item'           => __( 'Edit Schedule', 'event' ),
        'update_item'         => __( 'Update Schedule', 'event' ),
        'search_items'        => __( 'Search Schedules', 'event' ),
        'not_found'           => __( 'No Schedules found', 'event' ),
        'not_found_in_trash'  => __( 'No Schedules found in Trash', 'event' ),
    );
    $args = array(
        'label'               => __( 'schedule', 'event' ),
        'description'         => __( 'Schedule information pages', 'event' ),
        'labels'              => $labels,
        'supports'            => array( 'thumbnail', 'editor', 'title', 'comments','excerpt'),
        'taxonomies'          => array('categories'),
        'hierarchical'        => true,
        'public'              => true,
        'show_ui'             => true,
        'menu_icon'          => 'dashicons-calendar',
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => null,        
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
    );
    register_post_type( 'schedule', $args );
}

add_action( 'init', 'create_schedule_taxonomies', 0 );
// create categories taxonomy
function create_schedule_taxonomies() {
    // Add new taxonomy, make it hierarchical (like categories)
    $labels = array(
        'name'              => __( 'Categories', 'taxonomy general name' , 'event'),
        'singular_name'     => __( 'Categories', 'taxonomy singular name' , 'event'),
        'search_items'      => __( 'Search Categories', 'event'),
        'all_items'         => __( 'All Categories', 'event' ),
        'parent_item'       => __( 'Parent Category', 'event' ),
        'parent_item_colon' => __( 'Parent Category:' , 'event'),
        'edit_item'         => __( 'Edit Category' , 'event'),
        'update_item'       => __( 'Update Category' , 'event'),
        'add_new_item'      => __( 'Add New Category' , 'event'),
        'new_item_name'     => __( 'New Category Name' , 'event'),
        'menu_name'         => __( 'Categories' , 'event'),
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'schedule' )        
    );

    register_taxonomy( 'categories', array('schedule'), $args );
}

